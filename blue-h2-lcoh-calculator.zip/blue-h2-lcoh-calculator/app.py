"""Blue H2 LCOH Calculator - Streamlit App"""
import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
import sys
sys.path.insert(0, 'src')
from blue_h2_lcoh import calculate_lcoh, BlueH2Calculator, REFORMER_SPECS, GAS_PRICES

st.set_page_config(page_title="Blue H2 LCOH Calculator", page_icon="🔵", layout="wide")
st.title("🔵 Blue Hydrogen LCOH Calculator")
st.markdown("SMR/ATR with Carbon Capture and Storage")

# Sidebar
st.sidebar.header("⚙️ Configuration")
technology = st.sidebar.selectbox("Technology", list(REFORMER_SPECS.keys()),
                                   format_func=lambda x: REFORMER_SPECS[x]["name"])
capacity = st.sidebar.slider("Capacity (tonnes H2/day)", 50, 2000, 500)
gas_price = st.sidebar.slider("Natural Gas Price ($/MMBtu)", 1.0, 15.0, 3.0, 0.5)
capture_rate = st.sidebar.slider("CO2 Capture Rate (%)", 85, 99, 
                                  int(REFORMER_SPECS[technology]["capture_rate"]*100)) / 100

with st.sidebar.expander("🏭 CCUS Parameters"):
    ccus_capture = st.slider("Capture Cost ($/tonne)", 20, 100, 50)
    ccus_distance = st.slider("Transport Distance (km)", 0, 500, 100)
    ccus_storage = st.slider("Storage Cost ($/tonne)", 5, 30, 15)

with st.sidebar.expander("💰 Carbon & Financial"):
    carbon_price = st.slider("Carbon Price ($/tonne)", 0, 150, 0)
    discount_rate = st.slider("Discount Rate (%)", 5, 12, 8) / 100

# Calculate
result = calculate_lcoh(
    technology=technology, capacity_tonnes_per_day=capacity, gas_price=gas_price,
    capture_rate=capture_rate, ccus_capture_cost=ccus_capture,
    ccus_transport_distance=ccus_distance, ccus_storage_cost=ccus_storage,
    carbon_price=carbon_price, discount_rate=discount_rate,
)

# Metrics
c1, c2, c3, c4 = st.columns(4)
c1.metric("LCOH", f"${result.lcoh:.2f}/kg")
c2.metric("CO2 Captured", f"{result.co2_captured:.1f} kg/kg H2")
c3.metric("CO2 Emitted", f"{result.co2_emitted:.1f} kg/kg H2")
c4.metric("Annual Output", f"{result.annual_production_tonnes:,.0f} t/yr")

# Tabs
tab1, tab2, tab3 = st.tabs(["📊 Cost Breakdown", "🔄 Comparison", "📈 Sensitivity"])

with tab1:
    fig = go.Figure(go.Waterfall(
        x=["Reformer", "Natural Gas", "CCUS", "Carbon Tax", "Total"],
        y=[result.reformer_cost, result.gas_cost, result.ccus_cost, result.carbon_cost, 0],
        measure=["relative"]*4 + ["total"],
        connector={"line": {"color": "rgb(63,63,63)"}},
    ))
    fig.update_layout(title="LCOH Breakdown ($/kg H2)", height=400)
    st.plotly_chart(fig, use_container_width=True)

with tab2:
    calc = BlueH2Calculator()
    comp = calc.compare_technologies(gas_price=gas_price, capture_rate=capture_rate)
    fig2 = px.bar(x=[REFORMER_SPECS[t]["name"] for t in comp], y=[r.lcoh for r in comp.values()],
                  labels={"x": "Technology", "y": "LCOH ($/kg)"}, title="Technology Comparison")
    st.plotly_chart(fig2, use_container_width=True)
    
    # Blue vs Green
    st.subheader("Blue vs Green H2 Crossover")
    elec_prices = [0.02 + i*0.005 for i in range(20)]
    green_lcoh = [50*p + 1.0 for p in elec_prices]
    fig3 = go.Figure()
    fig3.add_trace(go.Scatter(x=elec_prices, y=green_lcoh, name="Green H2", line=dict(color="green")))
    fig3.add_hline(y=result.lcoh, line_dash="dash", line_color="blue", annotation_text=f"Blue H2: ${result.lcoh:.2f}")
    fig3.update_layout(xaxis_title="Electricity Price ($/kWh)", yaxis_title="LCOH ($/kg)")
    st.plotly_chart(fig3, use_container_width=True)

with tab3:
    gas_range = [1 + i*0.5 for i in range(20)]
    lcoh_sens = [calculate_lcoh(technology=technology, gas_price=g).lcoh for g in gas_range]
    fig4 = px.line(x=gas_range, y=lcoh_sens, labels={"x": "Gas Price ($/MMBtu)", "y": "LCOH ($/kg)"})
    fig4.add_vline(x=gas_price, line_dash="dash", line_color="red", annotation_text="Current")
    st.plotly_chart(fig4, use_container_width=True)

st.markdown("---")
st.markdown("**Author:** Bosco Chiramel | ORCID: 0009-0001-8456-5302")
