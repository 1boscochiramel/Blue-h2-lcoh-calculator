# Contributing

Thank you for your interest in contributing!

## How to Contribute

1. **Fork** the repository
2. **Clone** your fork: `git clone https://github.com/YOUR-USERNAME/REPO-NAME.git`
3. **Create a branch**: `git checkout -b feature/your-feature`
4. **Make changes** and add tests
5. **Run tests**: `pytest tests/ -v`
6. **Commit**: `git commit -m "Add your feature"`
7. **Push**: `git push origin feature/your-feature`
8. **Open a Pull Request**

## Code Style

- Use [Black](https://github.com/psf/black) for formatting
- Follow PEP 8 guidelines
- Add docstrings to functions and classes

## Testing

- Add tests for new features
- Ensure all tests pass before submitting PR
- Aim for >80% code coverage

## Questions?

Open an issue or contact the maintainer.
