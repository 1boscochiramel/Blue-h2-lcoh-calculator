# 🔵 Blue Hydrogen LCOH Calculator

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Tests](https://img.shields.io/badge/tests-8%20passed-brightgreen.svg)]()

**Levelized Cost of Hydrogen for SMR/ATR with Carbon Capture and Storage (CCUS).**

## 🎯 Features

- **4 Reformer Technologies:** SMR, SMR+, ATR, ATR+
- **CCUS Integration:** Capture, transport, storage costs
- **Regional Gas Prices:** US, Europe, Asia, Middle East
- **Blue vs Green Crossover:** Electricity price comparison
- **Carbon Price Impact:** Residual emissions costing

## 📊 Sample Output

| Technology | Gas $3/MMBtu | Capture Rate | LCOH |
|------------|--------------|--------------|------|
| SMR | $3.00 | 90% | $1.68/kg |
| SMR+ | $3.00 | 95% | $1.75/kg |
| ATR | $3.00 | 95% | $1.59/kg |
| ATR+ | $3.00 | 97% | $1.65/kg |

**MENA Advantage:** At $1.5/MMBtu gas → **$1.32/kg** (17% lower than US)

## 🚀 Quick Start

```bash
git clone https://github.com/bosco-chiramel/blue-h2-lcoh-calculator.git
cd blue-h2-lcoh-calculator
pip install -r requirements.txt
streamlit run app.py
```

## 💻 Python Usage

```python
from blue_h2_lcoh import calculate_lcoh

result = calculate_lcoh(
    reformer_type="atr",
    gas_price=2.5,  # $/MMBtu
    capture_rate=0.95,
    carbon_price=50,  # $/tonne
)
print(f"Blue H2 LCOH: ${result.lcoh:.2f}/kg")
print(f"CO2 Captured: {result.co2_captured:.1f} kg/kg H2")
```

## 🔬 Technology Comparison

| Tech | Efficiency | CAPEX | CO₂ Intensity | Capture |
|------|------------|-------|---------------|---------|
| SMR | 76% | $1,200/kg/day | 9.3 kg/kg | 90% |
| ATR | 78% | $1,400/kg/day | 8.5 kg/kg | 95% |
| ATR+ | 76% | $1,700/kg/day | 8.5 kg/kg | 97% |

## 📄 License

MIT License

## 👤 Author

**Bosco Chiramel** | [![ORCID](https://img.shields.io/badge/ORCID-0009--0001--8456--5302-green.svg)](https://orcid.org/0009-0001-8456-5302)
