"""Blue Hydrogen LCOH Calculator - SMR/ATR with CCUS.

LCOH = Reformer_Cost + Gas_Cost + CCUS_Cost + Carbon_Cost (residual emissions)
"""
from dataclasses import dataclass
from typing import Optional, Dict
from .data import REFORMER_SPECS, CCUS_COSTS, get_reformer_spec

@dataclass
class BlueH2Result:
    lcoh: float
    reformer_cost: float
    gas_cost: float
    ccus_cost: float
    carbon_cost: float
    co2_captured: float  # kg/kg H2
    co2_emitted: float   # kg/kg H2
    annual_production_tonnes: float
    
    def summary(self) -> str:
        return f"""
{'='*50}
BLUE HYDROGEN LCOH: ${self.lcoh:.2f}/kg
{'='*50}
Reformer Cost:    ${self.reformer_cost:.2f}/kg ({self.reformer_cost/self.lcoh*100:.1f}%)
Natural Gas:      ${self.gas_cost:.2f}/kg ({self.gas_cost/self.lcoh*100:.1f}%)
CCUS Cost:        ${self.ccus_cost:.2f}/kg ({self.ccus_cost/self.lcoh*100:.1f}%)
Carbon Cost:      ${self.carbon_cost:.2f}/kg ({self.carbon_cost/self.lcoh*100:.1f}%)
{'='*50}
CO2 Captured:     {self.co2_captured:.2f} kg/kg H2
CO2 Emitted:      {self.co2_emitted:.2f} kg/kg H2
Annual Output:    {self.annual_production_tonnes:,.0f} tonnes/year
{'='*50}
"""

class BlueH2Calculator:
    """Calculator for Blue Hydrogen LCOH (SMR/ATR + CCUS)."""
    
    def calculate_lcoh(
        self,
        technology: str = "smr",
        capacity_tonnes_per_day: float = 500,
        gas_price: float = 3.0,  # $/MMBtu
        capture_rate: Optional[float] = None,
        ccus_capture_cost: float = 50,  # $/tonne CO2
        ccus_transport_distance: float = 100,  # km
        ccus_storage_cost: float = 15,  # $/tonne
        carbon_price: float = 0,  # $/tonne for residual
        discount_rate: float = 0.08,
        project_lifetime: int = 25,
        capacity_factor: float = 0.95,
    ) -> BlueH2Result:
        spec = get_reformer_spec(technology)
        capture = capture_rate if capture_rate else spec["capture_rate"]
        
        # Annual production
        annual_kg = capacity_tonnes_per_day * 1000 * 365 * capacity_factor
        
        # Capital Recovery Factor
        crf = (discount_rate * (1+discount_rate)**project_lifetime) / ((1+discount_rate)**project_lifetime - 1)
        
        # 1. Reformer capital cost
        total_capex = spec["capex_per_kg_day"] * capacity_tonnes_per_day * 1000
        annual_capex = total_capex * crf
        annual_opex = total_capex * spec["opex_pct"] / 100
        reformer_cost = (annual_capex + annual_opex) / annual_kg
        
        # 2. Natural gas cost (with capture energy penalty)
        gas_consumption = spec["gas_mmbtu_per_kg"] * (1 + spec["capture_penalty"])
        gas_cost = gas_consumption * gas_price
        
        # 3. CCUS cost
        co2_produced = spec["base_co2_kg_per_kg_h2"]
        co2_captured = co2_produced * capture
        co2_emitted = co2_produced * (1 - capture)
        
        ccus_transport = CCUS_COSTS["transport_100km"] * ccus_transport_distance / 100
        ccus_per_tonne = ccus_capture_cost + ccus_transport + ccus_storage_cost
        ccus_cost = (co2_captured / 1000) * ccus_per_tonne  # $/kg H2
        
        # 4. Carbon cost on residual emissions
        carbon_cost = (co2_emitted / 1000) * carbon_price
        
        # Total LCOH
        lcoh = reformer_cost + gas_cost + ccus_cost + carbon_cost
        
        return BlueH2Result(
            lcoh=lcoh,
            reformer_cost=reformer_cost,
            gas_cost=gas_cost,
            ccus_cost=ccus_cost,
            carbon_cost=carbon_cost,
            co2_captured=co2_captured,
            co2_emitted=co2_emitted,
            annual_production_tonnes=annual_kg/1000,
        )
    
    def compare_technologies(self, gas_price: float = 3.0, **kwargs) -> Dict[str, BlueH2Result]:
        return {tech: self.calculate_lcoh(technology=tech, gas_price=gas_price, **kwargs) 
                for tech in REFORMER_SPECS}
    
    def compare_vs_green(self, gas_price: float, electricity_price: float, **kwargs) -> dict:
        """Compare blue vs green H2 at given prices."""
        blue = self.calculate_lcoh(gas_price=gas_price, **kwargs)
        # Green H2 estimate: ~50 kWh/kg * electricity price + ~$1/kg capital
        green_lcoh = 50 * electricity_price + 1.0
        return {"blue": blue.lcoh, "green": green_lcoh, "delta": blue.lcoh - green_lcoh}

def calculate_lcoh(technology: str = "smr", gas_price: float = 3.0, **kwargs) -> BlueH2Result:
    """Convenience function."""
    return BlueH2Calculator().calculate_lcoh(technology=technology, gas_price=gas_price, **kwargs)

def quick_lcoh(gas_price: float, technology: str = "smr") -> float:
    """Quick LCOH calculation."""
    return calculate_lcoh(technology=technology, gas_price=gas_price).lcoh
