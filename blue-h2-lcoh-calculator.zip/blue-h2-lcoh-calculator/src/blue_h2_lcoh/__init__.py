"""Blue Hydrogen LCOH Calculator - SMR/ATR with CCUS."""
__version__ = "1.0.0"
__author__ = "Bosco Chiramel"
from .calculator import BlueH2Calculator, BlueH2Result, calculate_lcoh, quick_lcoh
from .data import REFORMER_SPECS, CCUS_COSTS, GAS_PRICES, CARBON_PRICES, get_reformer_spec
__all__ = ["BlueH2Calculator", "BlueH2Result", "calculate_lcoh", "quick_lcoh",
           "REFORMER_SPECS", "CCUS_COSTS", "GAS_PRICES", "CARBON_PRICES", "get_reformer_spec"]
