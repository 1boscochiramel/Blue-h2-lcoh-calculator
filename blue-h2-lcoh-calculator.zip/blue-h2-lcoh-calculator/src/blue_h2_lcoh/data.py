"""Blue H2 data - SMR/ATR specifications, gas prices, CCUS costs."""

REFORMER_SPECS = {
    "smr": {
        "name": "Steam Methane Reforming (SMR)",
        "efficiency": 0.76, "gas_mmbtu_per_kg": 0.156,
        "capex_per_kg_day": 1200, "opex_pct": 4.0,
        "base_co2_kg_per_kg_h2": 9.3, "capture_rate": 0.90, "capture_penalty": 0.15,
    },
    "smr_plus": {
        "name": "SMR + Enhanced Capture",
        "efficiency": 0.74, "gas_mmbtu_per_kg": 0.162,
        "capex_per_kg_day": 1500, "opex_pct": 4.5,
        "base_co2_kg_per_kg_h2": 9.3, "capture_rate": 0.95, "capture_penalty": 0.20,
    },
    "atr": {
        "name": "Autothermal Reforming (ATR)",
        "efficiency": 0.78, "gas_mmbtu_per_kg": 0.150,
        "capex_per_kg_day": 1400, "opex_pct": 4.0,
        "base_co2_kg_per_kg_h2": 8.5, "capture_rate": 0.95, "capture_penalty": 0.12,
    },
    "atr_plus": {
        "name": "ATR + Max Capture",
        "efficiency": 0.76, "gas_mmbtu_per_kg": 0.155,
        "capex_per_kg_day": 1700, "opex_pct": 4.5,
        "base_co2_kg_per_kg_h2": 8.5, "capture_rate": 0.97, "capture_penalty": 0.15,
    },
}

CCUS_COSTS = {"capture": 50, "transport_100km": 5, "storage": 15}  # $/tonne CO2

GAS_PRICES = {  # $/MMBtu
    "us_henry_hub": 2.5, "europe_ttf": 8.0, "asia_jkm": 12.0,
    "middle_east": 1.5, "australia": 6.0,
}

CARBON_PRICES = {"eu_ets": 80, "us_45q": 85, "none": 0}  # $/tonne

def get_reformer_spec(tech: str) -> dict:
    if tech.lower() not in REFORMER_SPECS:
        raise ValueError(f"Unknown: {tech}. Options: {list(REFORMER_SPECS.keys())}")
    return REFORMER_SPECS[tech.lower()]
