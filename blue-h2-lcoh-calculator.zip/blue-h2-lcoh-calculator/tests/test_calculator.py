import pytest, sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))
from blue_h2_lcoh import calculate_lcoh, quick_lcoh, BlueH2Calculator, REFORMER_SPECS

def test_quick_lcoh():
    lcoh = quick_lcoh(gas_price=3.0)
    assert 1.0 < lcoh < 5.0

def test_smr_calculation():
    result = calculate_lcoh(technology="smr", gas_price=3.0)
    assert result.lcoh > 0
    assert result.co2_captured > result.co2_emitted

def test_atr_calculation():
    result = calculate_lcoh(technology="atr", gas_price=3.0)
    assert result.lcoh > 0

def test_gas_price_impact():
    low = calculate_lcoh(gas_price=2.0)
    high = calculate_lcoh(gas_price=6.0)
    assert high.lcoh > low.lcoh

def test_carbon_price_impact():
    no_carbon = calculate_lcoh(gas_price=3.0, carbon_price=0)
    with_carbon = calculate_lcoh(gas_price=3.0, carbon_price=100)
    assert with_carbon.lcoh > no_carbon.lcoh

def test_capture_rate():
    low_capture = calculate_lcoh(capture_rate=0.85)
    high_capture = calculate_lcoh(capture_rate=0.97)
    assert low_capture.co2_emitted > high_capture.co2_emitted

def test_compare_technologies():
    calc = BlueH2Calculator()
    results = calc.compare_technologies(gas_price=3.0)
    assert "smr" in results and "atr" in results

def test_middle_east_advantage():
    us = calculate_lcoh(gas_price=3.0)
    me = calculate_lcoh(gas_price=1.5)
    assert me.lcoh < us.lcoh

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
